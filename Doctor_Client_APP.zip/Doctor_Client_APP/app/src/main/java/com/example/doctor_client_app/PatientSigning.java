package com.example.doctor_client_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PatientSigning extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_page);
    }
}